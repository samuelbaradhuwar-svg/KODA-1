import React from "react";
import { KODA_ICON_BLACK, KODA_ICON_WHITE } from "../../assets/logo";

export function LogoMark({ className = "h-9 w-9", dark = true }) {
  return (
    <img
      src={dark ? KODA_ICON_WHITE : KODA_ICON_BLACK}
      alt="KODA logo mark"
      className={`${className} object-contain select-none`}
      draggable={false}
    />
  );
}

export function Logo({ dark = true }) {
  return (
    <div className="flex items-center gap-3 select-none">
      <LogoMark dark={dark} />
      <span className={`font-display font-bold uppercase tracking-tight text-[19px] ${dark ? "text-white" : "text-slate-900"}`}>
        KODA
      </span>
    </div>
  );
}
