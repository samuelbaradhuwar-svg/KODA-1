import React, { useState } from "react";
import { ChevronDown } from "lucide-react";
import { Reveal } from "./ui/Reveal";
import { Eyebrow } from "./ui/Eyebrow";
import { FAQS } from "../data/content";

function FaqItem({ item, isOpen, onClick }) {
  return (
    <div className="border-b border-slate-200">
      <button
        onClick={onClick}
        className="flex w-full items-center justify-between gap-4 py-5 text-left"
        aria-expanded={isOpen}
      >
        <span className="font-display text-[15.5px] font-medium text-slate-900">{item.q}</span>
        <ChevronDown
          className={`h-4.5 w-4.5 flex-shrink-0 text-slate-400 transition-transform duration-300 ${isOpen ? "rotate-180 text-blue-600" : ""}`}
        />
      </button>
      <div className={`grid transition-all duration-300 ease-out ${isOpen ? "grid-rows-[1fr] pb-5" : "grid-rows-[0fr]"}`} style={{ display: "grid" }}>
        <div className="overflow-hidden">
          <p className="text-[14px] leading-relaxed text-slate-500">{item.a}</p>
        </div>
      </div>
    </div>
  );
}

export default function Faq() {
  const [openIdx, setOpenIdx] = useState(0);
  return (
    <section data-nav-theme="light" className="bg-white py-24 sm:py-32">
      <div className="mx-auto max-w-3xl px-5 sm:px-8">
        <div className="text-center">
          <Reveal>
            <Eyebrow>FAQ</Eyebrow>
          </Reveal>
          <Reveal delay={80}>
            <h2 className="mt-5 font-display text-3xl font-semibold tracking-tight text-slate-900 sm:text-4xl">
              Common questions
            </h2>
          </Reveal>
        </div>

        <Reveal delay={140} className="mt-12">
          <div>
            {FAQS.map((item, i) => (
              <FaqItem key={item.q} item={item} isOpen={openIdx === i} onClick={() => setOpenIdx(openIdx === i ? -1 : i)} />
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
