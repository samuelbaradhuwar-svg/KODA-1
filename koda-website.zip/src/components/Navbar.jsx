import React, { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import { Logo } from "./ui/Logo";
import { PrimaryButton } from "./ui/Buttons";
import { scrollToId } from "../lib/utils";
import { NAV_LINKS } from "../data/content";

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [sectionTheme, setSectionTheme] = useState("dark");

  useEffect(() => {
    // Window scroll doesn't fire reliably inside every embedded/iframe context,
    // so a tiny sentinel + IntersectionObserver tracks "are we still at the very
    // top of the page" regardless of which element actually owns the scroll.
    const sentinel = document.getElementById("nova-top-sentinel");
    let topIO;
    if (sentinel) {
      topIO = new IntersectionObserver(
        ([entry]) => setScrolled(!entry.isIntersecting),
        { threshold: 0, rootMargin: "-1px 0px 0px 0px" }
      );
      topIO.observe(sentinel);
    }

    // Belt-and-suspenders fallback for plain window scrolling.
    const onScroll = () => {
      if (window.scrollY > 12) setScrolled(true);
    };
    window.addEventListener("scroll", onScroll, { passive: true });

    // Track which section sits directly under the fixed bar, so the bar can
    // switch to dark text over light sections instead of staying white-on-white.
    const themedSections = document.querySelectorAll("[data-nav-theme]");
    let themeIO;
    if (themedSections.length) {
      themeIO = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) setSectionTheme(entry.target.dataset.navTheme);
          });
        },
        { threshold: 0, rootMargin: "-84px 0px -92% 0px" }
      );
      themedSections.forEach((el) => themeIO.observe(el));
    }

    return () => {
      if (topIO) topIO.disconnect();
      if (themeIO) themeIO.disconnect();
      window.removeEventListener("scroll", onScroll);
    };
  }, []);

  const handleNav = (id) => {
    setOpen(false);
    scrollToId(id);
  };

  // At the very top the hero (dark) is always what's behind the bar; once
  // scrolled, follow whichever section is actually under it.
  const theme = !scrolled ? "dark" : sectionTheme;
  const isLight = theme === "light";

  // Solid inline backgrounds instead of Tailwind's bg-[#hex]/opacity arbitrary
  // classes — combined with backdrop-blur those were rendering as an almost
  // uncolored blur in some WebViews, leaving light text unreadable on light
  // sections. An inline rgba() background is guaranteed to actually paint.
  const barBg = !scrolled
    ? "transparent"
    : isLight
    ? "rgba(255,255,255,0.92)"
    : "rgba(17,24,39,0.92)";

  const panelBg = isLight ? "rgba(255,255,255,0.98)" : "rgba(17,24,39,0.98)";

  return (
    <header
      className={`fixed top-0 z-50 w-full transition-all duration-300 ${
        !scrolled
          ? "border-b border-transparent"
          : isLight
          ? "border-b border-slate-200 shadow-[0_1px_0_0_rgba(15,23,42,0.04)]"
          : "border-b border-white/10"
      }`}
      style={{
        backgroundColor: barBg,
        backdropFilter: scrolled ? "blur(28px) saturate(160%)" : undefined,
        WebkitBackdropFilter: scrolled ? "blur(28px) saturate(160%)" : undefined,
      }}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 sm:px-8">
        <button onClick={() => handleNav("home")} aria-label="KODA home">
          <Logo dark={!isLight} />
        </button>

        <div className="hidden items-center gap-8 lg:flex">
          {NAV_LINKS.map((link) => (
            <button
              key={link.id}
              onClick={() => handleNav(link.id)}
              className={`text-[13.5px] font-medium transition-colors ${
                isLight ? "text-slate-700 hover:text-slate-900" : "text-white/85 hover:text-white"
              }`}
            >
              {link.label}
            </button>
          ))}
        </div>

        <div className="hidden lg:block">
          <PrimaryButton onClick={() => handleNav("contact")} className="!px-5 !py-2.5 !text-[13px]">
            Book a Free Consultation
          </PrimaryButton>
        </div>

        <button
          className={`grid h-10 w-10 place-items-center rounded-full border transition-colors lg:hidden ${
            isLight ? "border-slate-200 text-slate-900" : "border-white/10 text-white"
          }`}
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle menu"
          aria-expanded={open}
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </nav>

      <div
        className={`overflow-hidden transition-all duration-300 lg:hidden ${
          open ? (isLight ? "max-h-96 border-b border-slate-200" : "max-h-96 border-b border-white/10") : "max-h-0"
        }`}
        style={{
          backgroundColor: open ? panelBg : "transparent",
          backdropFilter: open ? "blur(28px) saturate(160%)" : undefined,
          WebkitBackdropFilter: open ? "blur(28px) saturate(160%)" : undefined,
        }}
      >
        <div className="flex flex-col gap-1 px-5 py-4">
          {NAV_LINKS.map((link) => (
            <button
              key={link.id}
              onClick={() => handleNav(link.id)}
              className={`rounded-lg px-3 py-3 text-left text-[15px] font-semibold transition-colors ${
                isLight ? "text-slate-900 hover:bg-slate-100" : "text-white hover:bg-white/10"
              }`}
            >
              {link.label}
            </button>
          ))}
          <PrimaryButton onClick={() => handleNav("contact")} className="mt-2 w-full">
            Book a Free Consultation
          </PrimaryButton>
        </div>
      </div>
    </header>
  );
}
