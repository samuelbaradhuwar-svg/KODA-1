import React from "react";
import { ArrowRight, ShieldCheck, Star, MapPin, Clock3 } from "lucide-react";
import { Reveal } from "./ui/Reveal";
import { scrollToId } from "../lib/utils";

export default function CtaBand() {
  return (
    <section data-nav-theme="light" className="bg-white px-5 py-4 sm:px-8">
      <Reveal>
        <div className="relative mx-auto max-w-6xl overflow-hidden rounded-3xl bg-gradient-to-br from-blue-600 via-blue-600 to-indigo-700 px-8 py-14 text-center sm:py-16">
          <div className="nova-grid-light pointer-events-none absolute inset-0 opacity-10" />
          <h2 className="relative font-display text-2xl font-semibold tracking-tight text-white sm:text-3xl">
            Ready for a website that actually brings in customers?
          </h2>
          <p className="relative mx-auto mt-3 max-w-lg text-sm text-blue-100">
            Book a free consultation with no obligation, and we'll show you exactly what's possible for your business.
          </p>
          <div className="relative mt-8">
            <button
              onClick={() => scrollToId("contact")}
              className="inline-flex items-center gap-2 rounded-full bg-white px-7 py-3.5 text-sm font-semibold text-blue-700 shadow-xl transition-all duration-300 hover:-translate-y-0.5 hover:shadow-2xl"
            >
              Book a Free Consultation
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>

          <div className="relative mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 border-t border-white/15 pt-6 text-[11.5px] font-medium text-blue-100">
            <span className="flex items-center gap-1.5"><ShieldCheck className="h-3.5 w-3.5" /> SSL Secured</span>
            <span className="flex items-center gap-1.5"><Star className="h-3.5 w-3.5 fill-current" /> 5.0 Average Rating</span>
            <span className="flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5" /> South African Owned</span>
            <span className="flex items-center gap-1.5"><Clock3 className="h-3.5 w-3.5" /> Support Included</span>
          </div>
        </div>
      </Reveal>
    </section>
  );
}
