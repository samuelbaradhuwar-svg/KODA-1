import React from "react";
import { Star, TrendingUp } from "lucide-react";
import { Reveal } from "./ui/Reveal";
import { Eyebrow } from "./ui/Eyebrow";
import { PrimaryButton, SecondaryButton } from "./ui/Buttons";
import { scrollToId } from "../lib/utils";

function LaptopMockup() {
  return (
    <div className="relative">
      <div className="absolute -inset-8 -z-10 rounded-[2rem] bg-blue-600/20 blur-3xl" />

      {/* Laptop screen bezel */}
      <div className="rounded-t-2xl rounded-b-md border border-white/10 border-b-0 bg-[#1A1D26] p-2 shadow-2xl shadow-black/60">
      <div className="rounded-lg bg-[#0B0F1A]">
        <div className="flex items-center gap-2 border-b border-white/10 px-4 py-3">
          <span className="h-2.5 w-2.5 rounded-full bg-red-400/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-yellow-400/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-green-400/70" />
          <div className="ml-3 flex-1 rounded-md bg-white/5 px-3 py-1 text-[11px] text-slate-400">
            koda.co.za
          </div>
          <span className="flex items-center gap-1.5 rounded-full bg-green-500/10 px-2 py-1 text-[10px] font-medium text-green-400">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-green-400" />
            Live
          </span>
        </div>

        <div className="space-y-4 p-6">
          <div className="flex items-center justify-between">
            <div className="h-3 w-24 rounded-full bg-gradient-to-r from-blue-500 to-indigo-500 nova-shimmer" />
            <div className="flex gap-2">
              <div className="h-2 w-10 rounded-full bg-white/10 nova-shimmer" />
              <div className="h-2 w-10 rounded-full bg-white/10 nova-shimmer" />
              <div className="h-2 w-10 rounded-full bg-white/10 nova-shimmer" />
            </div>
          </div>

          <div className="space-y-2.5 pt-2">
            <div className="h-4 w-4/5 rounded-full bg-white/15 nova-shimmer" />
            <div className="h-4 w-3/5 rounded-full bg-white/15 nova-shimmer" style={{ animationDelay: "0.15s" }} />
            <div className="h-2.5 w-2/5 rounded-full bg-white/[0.07] nova-shimmer" style={{ animationDelay: "0.3s" }} />
          </div>

          <div className="flex gap-2 pt-1">
            <div className="h-8 w-28 rounded-full bg-blue-600 nova-shimmer" />
            <div className="h-8 w-24 rounded-full border border-white/15 nova-shimmer" style={{ animationDelay: "0.1s" }} />
          </div>

          <div className="grid grid-cols-3 gap-3 pt-3">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="aspect-square rounded-xl bg-gradient-to-br from-white/10 to-white/[0.02] nova-shimmer"
                style={{ animationDelay: `${i * 0.12}s` }}
              />
            ))}
          </div>
        </div>
      </div>
      </div>

      {/* Laptop base */}
      <div className="mx-auto h-3 w-[104%] max-w-none -translate-x-[2%] rounded-b-xl bg-gradient-to-b from-[#2A2E3A] to-[#15171E] shadow-lg" />
      <div className="mx-auto h-1.5 w-[34%] rounded-b-md bg-[#15171E]" />

      <div className="nova-float absolute -left-6 -bottom-16 flex items-center gap-3 rounded-2xl border border-white/10 bg-[#0B0F1A]/90 px-4 py-3 shadow-xl backdrop-blur">
        <div className="grid h-9 w-9 place-items-center rounded-full bg-blue-500/15 text-blue-400">
          <TrendingUp className="h-4 w-4" />
        </div>
        <div>
          <p className="text-sm font-semibold text-white">+184% enquiries</p>
          <p className="text-[11px] text-slate-400">since launch</p>
        </div>
      </div>

      <div className="nova-float-slow absolute -right-5 -top-6 flex items-center gap-2 rounded-2xl border border-white/10 bg-[#0B0F1A]/90 px-3.5 py-2.5 shadow-xl backdrop-blur">
        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
        <span className="text-xs font-semibold text-white">5.0 rating</span>
      </div>
    </div>
  );
}

export default function Hero() {
  return (
    <section id="home" data-nav-theme="dark" className="relative overflow-hidden bg-[#111827] pb-24 pt-32 sm:pb-32 sm:pt-40">
      <div className="nova-grid pointer-events-none absolute inset-0 opacity-[0.35]" />
      <div className="pointer-events-none absolute left-1/2 top-[-10%] h-[500px] w-[900px] -translate-x-1/2 rounded-full bg-blue-600/20 blur-[120px]" />

      <div className="relative mx-auto grid max-w-7xl grid-cols-1 items-center gap-16 px-5 sm:px-8 lg:grid-cols-2">
        <div>
          <Reveal>
            <Eyebrow dark>Websites for local businesses</Eyebrow>
          </Reveal>

          <Reveal delay={80}>
            <h1 className="mt-6 font-display text-4xl font-semibold leading-[1.08] tracking-tight text-white sm:text-5xl lg:text-[3.4rem]">
              Websites That Turn{" "}
              <span className="bg-gradient-to-r from-blue-400 via-blue-300 to-indigo-400 bg-clip-text text-transparent">
                Visitors Into Customers.
              </span>
            </h1>
          </Reveal>

          <Reveal delay={160}>
            <p className="mt-6 max-w-xl text-base leading-relaxed text-slate-400 sm:text-lg">
              We help South African businesses grow with modern websites that build trust, generate leads and make
              a lasting first impression, without the agency price tag or the six month timeline.
            </p>
          </Reveal>

          <Reveal delay={240}>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <PrimaryButton onClick={() => scrollToId("contact")}>Book a Free Consultation</PrimaryButton>
              <SecondaryButton dark onClick={() => scrollToId("portfolio")}>
                View Our Work
              </SecondaryButton>
            </div>
          </Reveal>

          <Reveal delay={320}>
            <div className="mt-12 flex flex-wrap items-center gap-x-8 gap-y-4 border-t border-white/10 pt-8">
              {[
                ["40+", "Local businesses launched"],
                ["5.0", "Average client rating"],
                ["7 days", "Typical turnaround"],
              ].map(([stat, label]) => (
                <div key={label}>
                  <p className="font-display text-2xl font-semibold text-white">{stat}</p>
                  <p className="text-xs text-slate-500">{label}</p>
                </div>
              ))}
            </div>
          </Reveal>
        </div>

        <Reveal delay={200} className="hidden lg:block">
          <LaptopMockup />
        </Reveal>
      </div>
    </section>
  );
}
