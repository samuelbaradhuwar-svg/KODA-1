import React from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Services from "./components/Services";
import WhyChooseUs from "./components/WhyChooseUs";
import Portfolio from "./components/Portfolio";
import Pricing from "./components/Pricing";
import Testimonials from "./components/Testimonials";
import Faq from "./components/Faq";
import CtaBand from "./components/CtaBand";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import WhatsAppButton from "./components/WhatsAppButton";

export default function App() {
  return (
    <div className="font-sans text-slate-900 antialiased" style={{ scrollBehavior: "smooth" }}>
      {/* Used by Navbar's IntersectionObserver to detect when the page has
          scrolled away from the very top, regardless of which element
          actually owns the scrolling. */}
      <div
        id="nova-top-sentinel"
        style={{ position: "absolute", top: 0, left: 0, height: 1, width: 1 }}
        aria-hidden="true"
      />

      <Navbar />
      <main>
        <Hero />
        <Services />
        <WhyChooseUs />
        <Portfolio />
        <Pricing />
        <Testimonials />
        <Faq />
        <CtaBand />
        <Contact />
      </main>
      <Footer />
      <WhatsAppButton />
    </div>
  );
}
